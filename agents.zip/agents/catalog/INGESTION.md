# Metadata ingestion plan

## Why this is federated

No authoritative public source contains every worldwide vehicle, ADS feature,
software version, ODD, permit, incident and local traffic rule. The platform
therefore joins bounded sources while preserving their original meaning.

## Record layers

1. **Raw:** immutable response, retrieval timestamp, URL, headers where
   permitted, content hash and license decision.
2. **Normalized:** source fields mapped to repository schemas without changing
   meaning or filling unknowns.
3. **Resolved:** entity links across manufacturer, make, model, configuration,
   software and jurisdiction, including ambiguity scores.
4. **Approved:** reviewed profile or rule pack eligible for production answers.

## Connector sequence

1. NHTSA vPIC for US-market manufacturer, VIN and base specification metadata.
2. Regulator permit, crash, recall and enforcement records for operational or
   safety claims.
3. Manufacturer manuals, safety reports and release notes for exact feature,
   responsibility, ODD and software claims.
4. Official legislation and road-authority material for executable rule packs.
5. Licensed research datasets for bounded training and evaluation, never as a
   substitute for current production evidence.

## Required field lineage

Every material normalized value records:

- source ID and source field or document locator;
- retrieved-at and effective-at dates;
- transformation name and version;
- unit and conversion, if any;
- manufacturer/model/configuration/software applicability;
- reviewer and approval state; and
- null reason when the value is unknown.

## Update behavior

Updates create new versions. They do not silently overwrite approved records.
A changed software version, law, permit, sensor configuration, formula input or
ODD triggers dependency impact analysis and re-evaluation.

## Prohibited ingestion behavior

- Scraping or redistributing data contrary to terms.
- Inferring ADS level or capability from make/model or marketing package name.
- Treating absence in a regional database as worldwide absence.
- Mixing records across software versions or vehicle configurations.
- Publishing personal or sensitive incident information without authorization.
