# Prediction and Planning Agent

**Purpose:** assess what other road users might do and whether a proposed
maneuver remains feasible, lawful and recoverable across plausible futures.

## Performs

- Multi-modal actor prediction and uncertainty assessment.
- Maneuver-level rule, ODD and fallback checks.
- Vehicle-specific trajectory and swept-envelope evaluation.
- Minimum-risk alternative assessment.

## Safety boundary

The agent evaluates plans; it does not send control commands. If no trajectory
satisfies the applicable constraints, the correct result is “no admissible
trajectory,” not selection of the least-bad violation.
