# Source Verification Agent

**Purpose:** make every material claim traceable to evidence that actually
supports it.

## Performs

- Classifies sources as law, regulator, standard, manufacturer, dataset,
  research or secondary evidence.
- Records publisher, date, scope, license and limitations.
- Distinguishes basic vehicle metadata from ADS capability and safety evidence.
- Detects stale, contradictory and scope-mismatched records.

## Does not perform

- Treat a web search result or marketing page as verified truth.
- Assume a missing public record means a feature does not exist.
- Download or redistribute a dataset without reviewing its terms.

## Key failure behavior

Unverifiable sources are quarantined. Conflicting primary sources remain
visible and cap confidence until resolved.
