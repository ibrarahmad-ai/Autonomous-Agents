# Business and Finance Agent

**Purpose:** connect autonomous-vehicle operations to trusted finance and
strategy answers, including gross-to-net forecasting.

## Performs

- Gross bookings/revenue to net-revenue reconciliation.
- Driver-based fleet, utilization, trip and cost forecasting.
- Contribution-margin and scenario analysis.
- Comparable-basis manufacturer or operating-model analysis.

## Finance boundary

The agent does not post entries or approve financial reporting. Private or
non-comparable data remains unknown, and forecasts include assumptions,
backtests and uncertainty rather than guaranteed point outcomes.
