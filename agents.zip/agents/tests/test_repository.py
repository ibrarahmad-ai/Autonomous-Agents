from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path


AGENTS_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(AGENTS_ROOT / "tools"))

from validate_repository import validate_repository  # noqa: E402


class RepositoryIntegrityTests(unittest.TestCase):
    def test_repository_validation_passes(self) -> None:
        result = validate_repository()
        self.assertEqual([], result.errors, "\n".join(result.errors))

    def test_expected_agent_set_is_present(self) -> None:
        catalog = json.loads((AGENTS_ROOT / "catalog" / "agents.json").read_text(encoding="utf-8"))
        ids = {entry["id"] for entry in catalog["agents"]}
        self.assertEqual(
            {
                "orchestrator", "source-verification", "perception-sensors",
                "localization-mapping", "prediction-planning",
                "vehicle-systems-control", "driving-rules",
                "safety-validation", "data-mlops", "regulation-risk",
                "business-finance",
            },
            ids,
        )

    def test_confidence_is_capped_at_99(self) -> None:
        schema = json.loads((AGENTS_ROOT / "schemas" / "query-response.schema.json").read_text(encoding="utf-8"))
        self.assertEqual(99, schema["properties"]["confidence"]["properties"]["percent"]["maximum"])

    def test_seed_rules_cannot_appear_legally_approved(self) -> None:
        seed = json.loads((AGENTS_ROOT / "rules" / "jurisdictions" / "CA-ON.seed.json").read_text(encoding="utf-8"))
        self.assertNotEqual("approved", seed["pack"]["status"])
        for rule in seed["rules"]:
            self.assertFalse(rule["legal_review"]["completed"])

    def test_vehicle_template_does_not_invent_capability(self) -> None:
        template = json.loads((AGENTS_ROOT / "profiles" / "vehicles" / "_template.json").read_text(encoding="utf-8"))
        self.assertEqual("unknown", template["automation"]["classification"])
        self.assertEqual([], template["automation"]["features"])


if __name__ == "__main__":
    unittest.main()
