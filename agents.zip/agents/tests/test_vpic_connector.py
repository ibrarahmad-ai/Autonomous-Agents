from __future__ import annotations

import argparse
import hashlib
import json
import sys
import unittest
from pathlib import Path


AGENTS_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(AGENTS_ROOT / "connectors"))

from fetch_vpic import build_url, make_envelope  # noqa: E402


class VpicConnectorTests(unittest.TestCase):
    def test_manufacturer_url_is_encoded(self) -> None:
        args = argparse.Namespace(mode="manufacturer-details", name="Example Motors & Co")
        self.assertEqual(
            "https://vpic.nhtsa.dot.gov/api/vehicles/GetManufacturerDetails/Example%20Motors%20%26%20Co?format=json",
            build_url(args),
        )

    def test_model_year_is_bounded(self) -> None:
        args = argparse.Namespace(mode="models-for-make-year", make="Example", year=1900)
        with self.assertRaises(ValueError):
            build_url(args)

    def test_envelope_hash_and_disclaimer(self) -> None:
        payload = {"Count": 1, "Message": "ok", "SearchCriteria": "x", "Results": [{"Mfr_ID": 1}]}
        raw = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        envelope = make_envelope("https://vpic.nhtsa.dot.gov/example", raw, payload, "2026-09-29T00:00:00+00:00")
        self.assertEqual(hashlib.sha256(raw).hexdigest(), envelope["sha256_raw"])
        self.assertEqual(1, envelope["count"])
        self.assertIn("not evidence of ADS capability", envelope["capability_disclaimer"])


if __name__ == "__main__":
    unittest.main()
