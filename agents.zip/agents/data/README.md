# Data storage boundary

Do not commit bulk datasets, personal data, credentials or unreviewed scraped
content to this repository.

Recommended runtime layout:

```text
data/
  raw/<source-id>/<retrieval-id>/       immutable source envelopes
  normalized/<schema-version>/          typed source records
  resolved/<entity-version>/            linked candidate profiles
  approved/<release-id>/                reviewed production records
```

Each runtime environment must define encryption, access control, retention,
backup, data residency and deletion rules. Dataset license terms take precedence
over this suggested layout.
