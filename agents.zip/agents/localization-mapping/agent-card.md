# Localization and Mapping Agent

**Purpose:** determine where the vehicle is, what the map represents and
whether the map still matches the physical road.

## Performs

- Pose-integrity, timestamp and coordinate-frame assessment.
- Map version, coverage, semantics and freshness checks.
- Live-versus-map change detection for closures and construction.
- OpenDRIVE-compatible road-network metadata analysis.

## Safety boundary

Maps provide prior information, not permission to drive through live occupied
or unresolved space. Frame ambiguity, stale coverage or a material map conflict
requires degradation or escalation.
