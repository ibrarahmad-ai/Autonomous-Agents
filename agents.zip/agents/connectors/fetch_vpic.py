"""Fetch bounded NHTSA vPIC metadata and preserve a verifiable raw envelope.

This connector intentionally does not classify automation capability.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen


BASE_URL = "https://vpic.nhtsa.dot.gov/api/vehicles"
USER_AGENT = "SOL-Autonomy-Metadata/0.1 (+local research connector)"


def build_url(args: argparse.Namespace) -> str:
    if args.mode == "manufacturers":
        if args.page < 1:
            raise ValueError("page must be at least 1")
        return f"{BASE_URL}/GetAllManufacturers?format=json&page={args.page}"
    if args.mode == "manufacturer-details":
        return f"{BASE_URL}/GetManufacturerDetails/{quote(args.name, safe='')}?format=json"
    if args.mode == "models-for-make-year":
        if not 1981 <= args.year <= 2100:
            raise ValueError("year must be between 1981 and 2100")
        return f"{BASE_URL}/GetModelsForMakeYear/make/{quote(args.make, safe='')}/modelyear/{args.year}?format=json"
    raise ValueError(f"unsupported mode: {args.mode}")


def fetch(url: str, timeout_seconds: int) -> tuple[bytes, dict[str, Any]]:
    request = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    with urlopen(request, timeout=timeout_seconds) as response:
        raw = response.read()
    payload = json.loads(raw.decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("vPIC response must be a JSON object")
    return raw, payload


def make_envelope(url: str, raw: bytes, payload: dict[str, Any], retrieved_at: str | None = None) -> dict[str, Any]:
    results = payload.get("Results", [])
    if not isinstance(results, list):
        raise ValueError("vPIC Results must be an array")
    return {
        "schema_version": "1.0.0",
        "source_id": "nhtsa-vpic",
        "endpoint": url,
        "retrieved_at": retrieved_at or datetime.now(timezone.utc).isoformat(),
        "sha256_raw": hashlib.sha256(raw).hexdigest(),
        "count": len(results),
        "message": payload.get("Message"),
        "search_criteria": payload.get("SearchCriteria"),
        "results": results,
        "capability_disclaimer": "Vehicle identity metadata is not evidence of ADS capability, ODD, software state or safety."
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Optional path for the raw evidence envelope")
    parser.add_argument("--timeout", type=int, default=20, help="Network timeout in seconds")
    subparsers = parser.add_subparsers(dest="mode", required=True)

    manufacturers = subparsers.add_parser("manufacturers", help="Fetch one page of manufacturer records")
    manufacturers.add_argument("--page", type=int, default=1)

    details = subparsers.add_parser("manufacturer-details", help="Fetch manufacturer details")
    details.add_argument("--name", required=True)

    models = subparsers.add_parser("models-for-make-year", help="Fetch models for a make and year")
    models.add_argument("--make", required=True)
    models.add_argument("--year", required=True, type=int)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        url = build_url(args)
        raw, payload = fetch(url, args.timeout)
        envelope = make_envelope(url, raw, payload)
    except (ValueError, HTTPError, URLError, TimeoutError) as exc:
        print(f"vPIC collection failed: {exc}", file=sys.stderr)
        return 1

    rendered = json.dumps(envelope, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        output = args.output.resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(rendered, encoding="utf-8")
        print(f"Wrote {envelope['count']} records to {output}")
    else:
        sys.stdout.write(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
