# Metadata connectors

Connectors fetch source records; they do not decide what those records prove.
Every connector must produce an immutable envelope containing the source ID,
exact endpoint, retrieval time and raw-content hash.

## NHTSA vPIC

Examples from the SOL root:

```powershell
python agents/connectors/fetch_vpic.py manufacturers --page 1
python agents/connectors/fetch_vpic.py manufacturer-details --name "General Motors"
python agents/connectors/fetch_vpic.py models-for-make-year --make Volvo --year 2026
```

Add `--output <path>` to save the raw envelope. Review vPIC rate limits and
terms before collection. The resulting data can establish US-market base
vehicle identity and submitted specifications. It cannot establish:

- installed ADS/ADAS hardware;
- automation level or fallback responsibility;
- current software version;
- operational design domain; or
- safety performance.

Those claims need configuration-specific manufacturer and regulatory evidence.

## Production requirements

Before enabling a connector in production, add license approval, authentication
where required, retry/backoff, rate limiting, data-retention controls, schema
versioning, monitoring and source-change tests.
