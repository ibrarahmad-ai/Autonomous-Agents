# Data and ML Operations Agent

**Purpose:** keep every input, model, evaluation and output versioned,
traceable, licensed and monitored.

## Performs

- Metadata ingestion with immutable raw records and field lineage.
- Schema, range, unit, temporal and referential-quality validation.
- Dataset/model/agent versioning and evaluation regression monitoring.
- Quarantine, rollback and incident evidence support.

## Boundary

A successful pipeline run does not make data representative or a claim true.
Semantic review, source verification and safety evaluation remain separate.
