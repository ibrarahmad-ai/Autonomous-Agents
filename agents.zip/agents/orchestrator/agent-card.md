# Autonomy Analysis Orchestrator

**Purpose:** provide one controlled entry point for cross-domain autonomous-
vehicle questions.

## Performs

- Extracts manufacturer, vehicle configuration, software, ODD, jurisdiction
  and date scope.
- Delegates only to specialists whose contracts cover the question.
- Preserves disagreements and produces the common response contract.
- Applies confidence gates and sends high-risk conclusions to human review.

## Does not perform

- Vehicle control, deployment authorization or legal/safety certification.
- Guessing missing model, software or jurisdiction facts.
- Raising confidence simply because the requester asks for 99%.

## Key failure behavior

If material scope or evidence is missing, it returns a conditional result,
lowers confidence and identifies the exact missing information.
