"""Dependency-free integrity checks for the SOL autonomy agent repository."""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


ROOT = Path(__file__).resolve().parents[1]


@dataclass
class ValidationResult:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    counts: dict[str, int] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.errors


def _load(path: Path, result: ValidationResult) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        result.errors.append(f"{path.relative_to(ROOT)}: cannot load JSON: {exc}")
        return None


def _require(mapping: dict[str, Any], keys: list[str], label: str, result: ValidationResult) -> None:
    for key in keys:
        if key not in mapping:
            result.errors.append(f"{label}: missing required key '{key}'")


def _is_iso_date(value: Any) -> bool:
    if value is None:
        return True
    if not isinstance(value, str):
        return False
    try:
        date.fromisoformat(value)
        return True
    except ValueError:
        return False


def _validate_all_json(result: ValidationResult) -> None:
    paths = sorted(ROOT.rglob("*.json"))
    for path in paths:
        _load(path, result)
    result.counts["json_files"] = len(paths)


def _validate_sources(result: ValidationResult) -> set[str]:
    payload = _load(ROOT / "catalog" / "sources.json", result) or {}
    sources = payload.get("sources", [])
    required = [
        "id", "name", "publisher", "url", "source_class", "authority",
        "coverage", "license", "freshness", "limitations", "verified_at",
    ]
    ids: set[str] = set()
    for index, source in enumerate(sources):
        label = f"catalog/sources.json sources[{index}]"
        if not isinstance(source, dict):
            result.errors.append(f"{label}: must be an object")
            continue
        _require(source, required, label, result)
        source_id = source.get("id")
        if source_id in ids:
            result.errors.append(f"{label}: duplicate source id '{source_id}'")
        if isinstance(source_id, str):
            ids.add(source_id)
        parsed = urlparse(str(source.get("url", "")))
        if parsed.scheme != "https" or not parsed.netloc:
            result.errors.append(f"{label}: source URL must be an absolute HTTPS URL")
        if not _is_iso_date(source.get("verified_at")):
            result.errors.append(f"{label}: verified_at must be an ISO date")
        if not source.get("limitations"):
            result.errors.append(f"{label}: at least one limitation is required")
    result.counts["sources"] = len(ids)
    return ids


def _load_evaluations(result: ValidationResult) -> dict[str, dict[str, Any]]:
    payload = _load(ROOT / "evals" / "cases.json", result) or {}
    cases = payload.get("cases", [])
    by_id: dict[str, dict[str, Any]] = {}
    for index, case in enumerate(cases):
        label = f"evals/cases.json cases[{index}]"
        if not isinstance(case, dict):
            result.errors.append(f"{label}: must be an object")
            continue
        _require(case, ["id", "agent", "scenario", "assertions"], label, result)
        case_id = case.get("id")
        if case_id in by_id:
            result.errors.append(f"{label}: duplicate evaluation id '{case_id}'")
        if isinstance(case_id, str):
            by_id[case_id] = case
        if not case.get("assertions"):
            result.errors.append(f"{label}: assertions cannot be empty")
    result.counts["evaluations"] = len(by_id)
    return by_id


def _validate_agents(result: ValidationResult, evaluations: dict[str, dict[str, Any]]) -> set[str]:
    catalog_path = ROOT / "catalog" / "agents.json"
    catalog = _load(catalog_path, result) or {}
    entries = catalog.get("agents", [])
    required_top = [
        "schema_version", "agent", "purpose", "scope", "skills",
        "output_contract", "confidence_policy", "escalation", "verification",
    ]
    ids: set[str] = set()
    expected_output = (ROOT / "schemas" / "query-response.schema.json").resolve()

    for index, entry in enumerate(entries):
        label = f"catalog/agents.json agents[{index}]"
        _require(entry, ["id", "path", "role"], label, result)
        manifest_path = (catalog_path.parent / str(entry.get("path", ""))).resolve()
        if not manifest_path.is_file():
            result.errors.append(f"{label}: manifest does not exist: {manifest_path}")
            continue
        manifest = _load(manifest_path, result) or {}
        relative = manifest_path.relative_to(ROOT)
        _require(manifest, required_top, str(relative), result)
        agent = manifest.get("agent", {})
        _require(agent, ["id", "name", "version", "owner", "status", "risk_class"], f"{relative} agent", result)
        agent_id = agent.get("id")
        if agent_id != entry.get("id"):
            result.errors.append(f"{relative}: agent id does not match catalog")
        if manifest_path.parent.name != agent_id:
            result.errors.append(f"{relative}: directory name must equal agent id")
        if agent_id in ids:
            result.errors.append(f"{relative}: duplicate agent id '{agent_id}'")
        if isinstance(agent_id, str):
            ids.add(agent_id)
        card = manifest_path.parent / "agent-card.md"
        if not card.is_file():
            result.errors.append(f"{relative}: missing agent-card.md")

        purpose = manifest.get("purpose", {})
        _require(purpose, ["objective", "users", "prohibited_uses"], f"{relative} purpose", result)
        scope = manifest.get("scope", {})
        _require(scope, ["manufacturers", "jurisdictions", "limitations"], f"{relative} scope", result)
        if not scope.get("limitations"):
            result.errors.append(f"{relative}: limitations cannot be empty")

        skill_ids: set[str] = set()
        for skill_index, skill in enumerate(manifest.get("skills", [])):
            skill_label = f"{relative} skills[{skill_index}]"
            _require(skill, ["id", "description", "inputs", "authorized_tools", "required_evidence", "failure_behavior"], skill_label, result)
            skill_id = skill.get("id")
            if skill_id in skill_ids:
                result.errors.append(f"{skill_label}: duplicate skill id '{skill_id}'")
            if isinstance(skill_id, str):
                skill_ids.add(skill_id)
            if not skill.get("required_evidence"):
                result.errors.append(f"{skill_label}: required_evidence cannot be empty")
            for tool in skill.get("authorized_tools", []):
                lowered = str(tool).lower()
                if any(term in lowered for term in ("actuator.write", "vehicle.control", "steering.write", "brake.write")):
                    result.errors.append(f"{skill_label}: forbidden vehicle-control tool '{tool}'")
        if not skill_ids:
            result.errors.append(f"{relative}: at least one skill is required")

        output_path = (manifest_path.parent / str(manifest.get("output_contract", ""))).resolve()
        if output_path != expected_output:
            result.errors.append(f"{relative}: output_contract must resolve to the common response schema")
        confidence = manifest.get("confidence_policy", {})
        maximum = confidence.get("maximum_without_human_review")
        if not isinstance(maximum, int) or not 0 <= maximum <= 98:
            result.errors.append(f"{relative}: maximum_without_human_review must be an integer from 0 to 98")

        verification = manifest.get("verification", {})
        _require(verification, ["evaluation_ids", "acceptance"], f"{relative} verification", result)
        for eval_id in verification.get("evaluation_ids", []):
            case = evaluations.get(eval_id)
            if case is None:
                result.errors.append(f"{relative}: unknown evaluation id '{eval_id}'")
            elif case.get("agent") != agent_id:
                result.errors.append(f"{relative}: evaluation '{eval_id}' belongs to a different agent")

    evaluation_agents = {case.get("agent") for case in evaluations.values()}
    for agent_id in ids - evaluation_agents:
        result.errors.append(f"agent '{agent_id}' has no evaluation case")
    result.counts["agents"] = len(ids)
    result.counts["skills"] = sum(
        len((_load((catalog_path.parent / entry["path"]).resolve(), ValidationResult()) or {}).get("skills", []))
        for entry in entries if "path" in entry and (catalog_path.parent / entry["path"]).resolve().is_file()
    )
    return ids


def _validate_rules(result: ValidationResult, source_ids: set[str]) -> None:
    rule_ids: set[str] = set()
    packs = 0
    for path in sorted((ROOT / "rules" / "jurisdictions").glob("*.json")):
        if path.name.startswith("_"):
            continue
        payload = _load(path, result) or {}
        pack = payload.get("pack", {})
        _require(pack, ["id", "jurisdiction", "version", "status", "effective_from", "effective_to", "driving_side", "legal_review_required"], f"{path.relative_to(ROOT)} pack", result)
        if not _is_iso_date(pack.get("effective_from")) or not _is_iso_date(pack.get("effective_to")):
            result.errors.append(f"{path.relative_to(ROOT)}: invalid effective date")
        packs += 1
        for index, rule in enumerate(payload.get("rules", [])):
            label = f"{path.relative_to(ROOT)} rules[{index}]"
            _require(rule, ["id", "jurisdiction", "category", "statement", "conditions", "required_behavior", "exceptions", "priority", "source_refs", "effective", "status", "legal_review"], label, result)
            rule_id = rule.get("id")
            if rule_id in rule_ids:
                result.errors.append(f"{label}: duplicate rule id '{rule_id}'")
            if isinstance(rule_id, str):
                rule_ids.add(rule_id)
            if rule.get("jurisdiction") != pack.get("id"):
                result.errors.append(f"{label}: rule jurisdiction must match pack id")
            for reference in rule.get("source_refs", []):
                if reference.get("source_id") not in source_ids:
                    result.errors.append(f"{label}: unknown source id '{reference.get('source_id')}'")
                if not reference.get("locator"):
                    result.errors.append(f"{label}: source locator is required")
            legal_review = rule.get("legal_review", {})
            if rule.get("status") == "approved" and not legal_review.get("completed"):
                result.errors.append(f"{label}: approved rule requires completed legal review")
        if pack.get("status") != "approved":
            result.warnings.append(f"{path.relative_to(ROOT)}: jurisdiction pack is not approved")
    result.counts["jurisdiction_packs"] = packs
    result.counts["driving_rules"] = len(rule_ids)


def _validate_calculations(result: ValidationResult) -> None:
    payload = _load(ROOT / "catalog" / "calculations.json", result) or {}
    ids: set[str] = set()
    for index, calculation in enumerate(payload.get("calculations", [])):
        label = f"catalog/calculations.json calculations[{index}]"
        _require(calculation, ["id", "equation", "inputs", "applicability", "reject_when"], label, result)
        calc_id = calculation.get("id")
        if calc_id in ids:
            result.errors.append(f"{label}: duplicate calculation id '{calc_id}'")
        if isinstance(calc_id, str):
            ids.add(calc_id)
        if not calculation.get("reject_when"):
            result.errors.append(f"{label}: reject_when cannot be empty")
    result.counts["calculations"] = len(ids)


def _validate_assurance(result: ValidationResult) -> None:
    payload = _load(ROOT / "assurance" / "claims.json", result) or {}
    ids: set[str] = set()
    for index, claim in enumerate(payload.get("claims", [])):
        label = f"assurance/claims.json claims[{index}]"
        _require(claim, ["id", "claim", "scope", "argument", "evidence", "defeaters", "status"], label, result)
        claim_id = claim.get("id")
        if claim_id in ids:
            result.errors.append(f"{label}: duplicate claim id '{claim_id}'")
        if isinstance(claim_id, str):
            ids.add(claim_id)
        for evidence in claim.get("evidence", []):
            if not (ROOT / evidence).exists():
                result.errors.append(f"{label}: evidence path does not exist: {evidence}")
        if not claim.get("defeaters"):
            result.errors.append(f"{label}: at least one defeater is required")
    result.counts["assurance_claims"] = len(ids)


def _validate_confidence_contract(result: ValidationResult) -> None:
    schema = _load(ROOT / "schemas" / "query-response.schema.json", result) or {}
    try:
        maximum = schema["properties"]["confidence"]["properties"]["percent"]["maximum"]
        required = set(schema["required"])
    except (KeyError, TypeError):
        result.errors.append("schemas/query-response.schema.json: confidence structure is invalid")
        return
    if maximum != 99:
        result.errors.append("query response confidence maximum must be 99")
    expected = {"conclusion", "confidence", "supporting_evidence", "assumptions", "remaining_uncertainty", "scope", "as_of_date", "escalation"}
    missing = expected - required
    if missing:
        result.errors.append(f"query response schema is missing required fields: {sorted(missing)}")


def validate_repository(root: Path | None = None) -> ValidationResult:
    if root is not None and root.resolve() != ROOT.resolve():
        raise ValueError(f"This validator is bound to {ROOT}")
    result = ValidationResult()
    _validate_all_json(result)
    source_ids = _validate_sources(result)
    evaluations = _load_evaluations(result)
    _validate_agents(result, evaluations)
    _validate_rules(result, source_ids)
    _validate_calculations(result)
    _validate_assurance(result)
    _validate_confidence_contract(result)
    return result


def main() -> int:
    result = validate_repository()
    for warning in result.warnings:
        print(f"WARNING: {warning}")
    for error in result.errors:
        print(f"ERROR: {error}")
    counts = ", ".join(f"{key}={value}" for key, value in sorted(result.counts.items()))
    print(f"Validated {counts}")
    print("PASS" if result.ok else "FAIL")
    return 0 if result.ok else 1


if __name__ == "__main__":
    sys.exit(main())
